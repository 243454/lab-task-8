import { Injectable, BadRequestException, NotFoundException } from '@nestjs/common';
import { DataService } from '../data/data.service';
@Injectable()
export class OrdersService {
  constructor(private store: DataService) {}
  create(body: any) {
    const { userId, address, phone } = body;
    if (!userId || !address || !phone) throw new BadRequestException('User ID, address and phone are required');
    const data = this.store.read(); const user = data.users.find(u => u.id === Number(userId));
    if (!user) throw new NotFoundException('User not found');
    const cart = data.carts.filter(c => c.userId === Number(userId));
    if (!cart.length) throw new BadRequestException('Cart is empty');
    const items = cart.map(c => { const p = data.products.find(x => x.id === c.productId); return { productId: c.productId, name: p ? p.name : 'Deleted product', price: p ? p.price : 0, quantity: c.quantity }; });
    const total = items.reduce((sum, item) => sum + item.price * item.quantity, 0);
    const order = { id: this.store.nextId(data.orders), userId: Number(userId), customerName: user.name, address, phone, items, total: Number(total.toFixed(2)), status: 'Placed', createdAt: new Date().toISOString() };
    data.orders.push(order); data.carts = data.carts.filter(c => c.userId !== Number(userId)); this.store.write(data);
    return { message: 'Order placed successfully', order };
  }
  findAll() { return this.store.read().orders; }
  findOne(id: number) { const order = this.store.read().orders.find(o => o.id === id); if (!order) throw new NotFoundException('Order not found'); return order; }
}