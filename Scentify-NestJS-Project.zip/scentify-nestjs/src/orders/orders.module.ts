import { Module } from '@nestjs/common';
import { OrdersController } from './orders.controller';
import { OrdersService } from './orders.service';
import { DataService } from '../data/data.service';
@Module({ controllers: [OrdersController], providers: [OrdersService, DataService] })
export class OrdersModule {}