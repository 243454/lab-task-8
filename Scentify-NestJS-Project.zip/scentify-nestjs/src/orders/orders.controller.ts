import { Controller, Get, Post, Param, Body, ParseIntPipe } from '@nestjs/common';
import { OrdersService } from './orders.service';
@Controller('api/orders')
export class OrdersController {
  constructor(private service: OrdersService) {}
  @Post() create(@Body() body: any) { return this.service.create(body); }
  @Get() findAll() { return this.service.findAll(); }
  @Get(':id') findOne(@Param('id', ParseIntPipe) id: number) { return this.service.findOne(id); }
}