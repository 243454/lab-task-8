import { Controller, Post, Body } from '@nestjs/common';
import { UsersService } from './users.service';
@Controller('api/users')
export class UsersController {
  constructor(private service: UsersService) {}
  @Post('signup') signup(@Body() body: any) { return this.service.signup(body); }
  @Post('login') login(@Body() body: any) { return this.service.login(body); }
}