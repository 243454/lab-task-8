import { Module } from '@nestjs/common';
import { UsersController } from './users.controller';
import { UsersService } from './users.service';
import { DataService } from '../data/data.service';
@Module({ controllers: [UsersController], providers: [UsersService, DataService] })
export class UsersModule {}