import { Injectable, BadRequestException, ConflictException, UnauthorizedException } from '@nestjs/common';
import { DataService } from '../data/data.service';
import * as crypto from 'crypto';
@Injectable()
export class UsersService {
  constructor(private store: DataService) {}
  signup(body: any) {
    const { name, email, password } = body;
    if (!name || !email || !password) throw new BadRequestException('Name, email and password are required');
    const data = this.store.read();
    if (data.users.some(u => u.email.toLowerCase() === String(email).toLowerCase())) throw new ConflictException('Email already registered');
    const user = { id: this.store.nextId(data.users), name, email, passwordHash: crypto.createHash('sha256').update(String(password)).digest('hex') };
    data.users.push(user); this.store.write(data);
    return { id: user.id, name: user.name, email: user.email, message: 'Signup successful' };
  }
  login(body: any) {
    const data = this.store.read(); const hash = crypto.createHash('sha256').update(String(body.password || '')).digest('hex');
    const user = data.users.find(u => u.email.toLowerCase() === String(body.email || '').toLowerCase() && u.passwordHash === hash);
    if (!user) throw new UnauthorizedException('Invalid email or password');
    return { id: user.id, name: user.name, email: user.email, message: 'Login successful' };
  }
}