import { NestFactory } from '@nestjs/core';
import { AppModule } from './app.module';
import { join } from 'path';
import * as express from 'express';

async function bootstrap() {
  const app = await NestFactory.create(AppModule);
  // Serve the original website files from the public folder.
  app.use(express.static(join(__dirname, '..', 'public')));
  app.enableCors();
  await app.listen(3000);
  console.log('Scentify is running at http://localhost:3000');
}
bootstrap();