import { Injectable } from '@nestjs/common';
import * as fs from 'fs';
import { join } from 'path';

// This service reads and writes data.json so data remains after restarting NestJS.
@Injectable()
export class DataService {
  private file = join(process.cwd(), 'data.json');
  private initialData = {
    products: [
      { id: 1, name: 'S1 By Qamar', price: 49.99, description: 'Elegant and long-lasting fragrance.', stock: 20 },
      { id: 2, name: 'S2 By Qamar', price: 59.99, description: 'Fresh fragrance for everyday use.', stock: 20 },
      { id: 3, name: 'S3 By Qamar', price: 39.99, description: 'A sophisticated modern scent.', stock: 20 },
      { id: 4, name: 'S4 By Qamar', price: 69.99, description: 'A bold and luxurious fragrance.', stock: 20 }
    ], users: [], carts: [], orders: []
  };

  read() {
    if (!fs.existsSync(this.file)) this.write(this.initialData);
    return JSON.parse(fs.readFileSync(this.file, 'utf8'));
  }
  write(data: any) { fs.writeFileSync(this.file, JSON.stringify(data, null, 2)); }
  nextId(items: any[]) { return items.length ? Math.max(...items.map(x => x.id)) + 1 : 1; }
}