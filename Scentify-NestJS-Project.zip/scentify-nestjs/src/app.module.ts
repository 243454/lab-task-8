import { Module } from '@nestjs/common';
import { DataService } from './data/data.service';
import { AppController } from './app.controller';
import { ProductsModule } from './products/products.module';
import { UsersModule } from './users/users.module';
import { CartModule } from './cart/cart.module';
import { OrdersModule } from './orders/orders.module';

@Module({
  imports: [ProductsModule, UsersModule, CartModule, OrdersModule],
  controllers: [AppController],
  providers: [DataService],
  exports: [DataService],
})
export class AppModule {}