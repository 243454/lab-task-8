import { Injectable, BadRequestException, NotFoundException } from '@nestjs/common';
import { DataService } from '../data/data.service';
@Injectable()
export class ProductsService {
  constructor(private dataService: DataService) {}
  findAll() { return this.dataService.read().products; }
  findOne(id: number) {
    const product = this.dataService.read().products.find(p => p.id === id);
    if (!product) throw new NotFoundException('Product not found');
    return product;
  }
  create(body: any) {
    if (!body.name || !Number.isFinite(Number(body.price)) || Number(body.price) < 0) throw new BadRequestException('A product name and valid non-negative price are required');
    const data = this.dataService.read();
    const product = { id: this.dataService.nextId(data.products), name: body.name, price: Number(body.price), description: body.description || '', stock: Number(body.stock || 0) };
    data.products.push(product); this.dataService.write(data); return product;
  }
  update(id: number, body: any) {
    const data = this.dataService.read(); const product = data.products.find(p => p.id === id);
    if (!product) throw new NotFoundException('Product not found');
    if (body.price !== undefined && (!Number.isFinite(Number(body.price)) || Number(body.price) < 0)) throw new BadRequestException('Invalid price');
    ['name', 'description', 'stock'].forEach(key => { if (body[key] !== undefined) product[key] = key === 'stock' ? Number(body[key]) : body[key]; });
    if (body.price !== undefined) product.price = Number(body.price);
    this.dataService.write(data); return product;
  }
  remove(id: number) {
    const data = this.dataService.read(); const index = data.products.findIndex(p => p.id === id);
    if (index < 0) throw new NotFoundException('Product not found');
    const removed = data.products.splice(index, 1)[0]; this.dataService.write(data); return { message: 'Product deleted', product: removed };
  }
}