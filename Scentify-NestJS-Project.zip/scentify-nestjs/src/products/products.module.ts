import { Module } from '@nestjs/common';
import { ProductsController } from './products.controller';
import { ProductsService } from './products.service';
import { DataService } from '../data/data.service';
@Module({ controllers: [ProductsController], providers: [ProductsService, DataService] })
export class ProductsModule {}