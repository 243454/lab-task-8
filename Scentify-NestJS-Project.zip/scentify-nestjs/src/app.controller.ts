import { Controller, Get } from '@nestjs/common';
@Controller('api')
export class AppController {
  @Get() home() { return { message: 'Scentify NestJS API is running' }; }
}
