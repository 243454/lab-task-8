import { Module } from '@nestjs/common';
import { CartController } from './cart.controller';
import { CartService } from './cart.service';
import { DataService } from '../data/data.service';
@Module({ controllers: [CartController], providers: [CartService, DataService] })
export class CartModule {}