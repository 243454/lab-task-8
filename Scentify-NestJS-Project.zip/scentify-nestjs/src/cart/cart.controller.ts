import { Controller, Get, Post, Put, Delete, Param, Body, ParseIntPipe } from '@nestjs/common';
import { CartService } from './cart.service';
@Controller('api/cart')
export class CartController {
  constructor(private service: CartService) {}
  @Get(':userId') getCart(@Param('userId', ParseIntPipe) userId: number) { return this.service.getCart(userId); }
  @Post(':userId/items') add(@Param('userId', ParseIntPipe) userId: number, @Body() body: any) { return this.service.add(userId, body); }
  @Put(':userId/items/:productId') update(@Param('userId', ParseIntPipe) userId: number, @Param('productId', ParseIntPipe) productId: number, @Body() body: any) { return this.service.update(userId, productId, body); }
  @Delete(':userId/items/:productId') remove(@Param('userId', ParseIntPipe) userId: number, @Param('productId', ParseIntPipe) productId: number) { return this.service.remove(userId, productId); }
}