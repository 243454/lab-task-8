import { Injectable, NotFoundException, BadRequestException } from '@nestjs/common';
import { DataService } from '../data/data.service';
@Injectable()
export class CartService {
  constructor(private store: DataService) {}
  getCart(userId: number) {
    const data = this.store.read();
    return data.carts.filter(c => c.userId === userId).map(item => ({ ...item, product: data.products.find(p => p.id === item.productId) || null }));
  }
  add(userId: number, body: any) {
    const productId = Number(body.productId); const quantity = Number(body.quantity || 1);
    if (!Number.isInteger(quantity) || quantity < 1) throw new BadRequestException('Quantity must be a positive integer');
    const data = this.store.read();
    if (!data.users.some(u => u.id === userId)) throw new NotFoundException('User not found');
    if (!data.products.some(p => p.id === productId)) throw new NotFoundException('Product not found');
    let item = data.carts.find(c => c.userId === userId && c.productId === productId);
    if (item) item.quantity += quantity; else { item = { id: this.store.nextId(data.carts), userId, productId, quantity }; data.carts.push(item); }
    this.store.write(data); return item;
  }
  update(userId: number, productId: number, body: any) {
    const data = this.store.read(); const item = data.carts.find(c => c.userId === userId && c.productId === productId);
    if (!item) throw new NotFoundException('Cart item not found');
    const quantity = Number(body.quantity); if (!Number.isInteger(quantity) || quantity < 1) throw new BadRequestException('Quantity must be a positive integer');
    item.quantity = quantity; this.store.write(data); return item;
  }
  remove(userId: number, productId: number) {
    const data = this.store.read(); const index = data.carts.findIndex(c => c.userId === userId && c.productId === productId);
    if (index < 0) throw new NotFoundException('Cart item not found');
    data.carts.splice(index, 1); this.store.write(data); return { message: 'Item removed from cart' };
  }
}