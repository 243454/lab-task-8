const API = '/api';
const userId = () => Number(localStorage.getItem('scentifyUserId'));
const money = value => '$' + Number(value).toFixed(2);
async function request(url, options = {}) {
  const response = await fetch(API + url, { headers: { 'Content-Type': 'application/json' }, ...options });
  const data = await response.json();
  if (!response.ok) throw new Error(data.message || 'Request failed');
  return data;
}
function message(text) { alert(text); }

// HOME: load products from NestJS and create Add to Cart buttons.
async function loadProducts() {
  const section = document.querySelector('#products .row.g-4'); if (!section) return;
  try {
    const products = await request('/products');
    section.innerHTML = products.map(p => `<div class="col-md-6 col-lg-3"><div class="card product-card h-100"><div class="product-image">${p.name.split(' ')[0]}</div><div class="card-body"><h5>${p.name}</h5><p class="text-muted">${p.description}</p><h5>${money(p.price)}</h5><button class="btn btn-dark w-100" onclick="addToCart(${p.id})">Add to Cart</button></div></div></div>`).join('');
  } catch (e) { message(e.message); }
}
async function addToCart(productId) {
  if (!userId()) { message('Please login first.'); location.href = 'login.html'; return; }
  try { await request(`/cart/${userId()}/items`, { method: 'POST', body: JSON.stringify({ productId, quantity: 1 }) }); message('Product added to cart'); }
  catch (e) { message(e.message); }
}

// SIGNUP and LOGIN forms.
const forms = document.querySelectorAll('form');
if (location.pathname.endsWith('signup.html') && forms[0]) {
  forms[0].addEventListener('submit', async e => {
    e.preventDefault(); const inputs = forms[0].querySelectorAll('input');
    if (inputs[2].value !== inputs[3].value) return message('Passwords do not match');
    try { const user = await request('/users/signup', { method: 'POST', body: JSON.stringify({ name: inputs[0].value, email: inputs[1].value, password: inputs[2].value }) }); localStorage.setItem('scentifyUserId', user.id); localStorage.setItem('scentifyUserName', user.name); message('Signup successful'); location.href = 'index.html'; }
    catch (err) { message(err.message); }
  });
}
if (location.pathname.endsWith('login.html') && forms[0]) {
  forms[0].addEventListener('submit', async e => {
    e.preventDefault(); const inputs = forms[0].querySelectorAll('input');
    try { const user = await request('/users/login', { method: 'POST', body: JSON.stringify({ email: inputs[0].value, password: inputs[1].value }) }); localStorage.setItem('scentifyUserId', user.id); localStorage.setItem('scentifyUserName', user.name); message('Login successful'); location.href = 'index.html'; }
    catch (err) { message(err.message); }
  });
}

// CART: render actual saved cart items, change quantities and remove items.
async function loadCart() {
  const container = document.querySelector('[data-cart-items]'); if (!container) return;
  if (!userId()) { container.innerHTML = '<p>Please login to view your cart.</p>'; return; }
  try {
    const items = await request(`/cart/${userId()}`); let total = 0;
    container.innerHTML = items.length ? items.map(item => { const p = item.product || {}; const line = (p.price || 0) * item.quantity; total += line; return `<div class="card mb-3"><div class="card-body d-flex justify-content-between align-items-center flex-wrap gap-3"><div><h5>${p.name || 'Product'}</h5><p>${money(p.price || 0)}</p></div><input type="number" min="1" value="${item.quantity}" style="width:80px" onchange="changeQuantity(${p.id},this.value)"><button class="btn btn-outline-danger" onclick="removeItem(${p.id})">Remove</button><strong>${money(line)}</strong></div></div>`; }).join('') : '<p>Your cart is empty.</p>';
    const totalNode = document.querySelector('[data-cart-total]'); if (totalNode) totalNode.textContent = money(total);
  } catch (e) { message(e.message); }
}
async function changeQuantity(productId, quantity) { try { await request(`/cart/${userId()}/items/${productId}`, { method: 'PUT', body: JSON.stringify({ quantity: Number(quantity) }) }); loadCart(); } catch (e) { message(e.message); } }
async function removeItem(productId) { try { await request(`/cart/${userId()}/items/${productId}`, { method: 'DELETE' }); loadCart(); } catch (e) { message(e.message); } }

// CHECKOUT: place an order using the user's cart.
if (location.pathname.endsWith('checkout.html') && forms[0]) {
  forms[0].addEventListener('submit', async e => {
    e.preventDefault(); if (!userId()) return message('Please login first');
    const inputs = forms[0].querySelectorAll('input, textarea');
    try { const result = await request('/orders', { method: 'POST', body: JSON.stringify({ userId: userId(), address: inputs[3].value, phone: inputs[2].value }) }); message(result.message + '. Order total: ' + money(result.order.total)); location.href = 'index.html'; }
    catch (err) { message(err.message); }
  });
}
if (document.querySelector('#products .row.g-4')) loadProducts();
if (document.querySelector('[data-cart-items]')) loadCart();
