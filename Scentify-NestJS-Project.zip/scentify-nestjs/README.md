# Scentify E-commerce — NestJS version

This project recreates the supplied Scentify Lab Task 7 Question 2 project using NestJS. It keeps the Bootstrap/HTML/CSS website style and provides NestJS REST APIs for products, users, cart and orders. The frontend uses `public/js/app.js` to call those APIs.

## Requirements
- Node.js (LTS recommended)
- VS Code
- Internet connection for the Bootstrap CDN

## Install and run
1. Extract this ZIP.
2. Open the `scentify-nestjs` folder in VS Code.
3. Open Terminal in that folder.
4. Run `npm install`.
5. Run `npm run start:dev`.
6. Open `http://localhost:3000`.

The first server start creates `data.json` automatically. It stores products, users, carts and orders. Do not delete it if you want to keep your test data.

## API routes

### Products (CRUD)
- `GET /api/products` — all products
- `GET /api/products/1` — one product
- `POST /api/products` — create product; JSON: `{"name":"S5 By Qamar","price":55.5,"description":"A new fragrance","stock":10}`
- `PUT /api/products/1` — update product; JSON fields can include name, price, description, stock
- `DELETE /api/products/1` — delete product

### Users
- `POST /api/users/signup` — JSON: `{"name":"Ali Khan","email":"ali@example.com","password":"pass123"}`
- `POST /api/users/login` — JSON: `{"email":"ali@example.com","password":"pass123"}`

### Cart (use the numeric user ID returned by signup/login)
- `GET /api/cart/1`
- `POST /api/cart/1/items` — JSON: `{"productId":1,"quantity":1}`
- `PUT /api/cart/1/items/1` — JSON: `{"quantity":2}`
- `DELETE /api/cart/1/items/1`

### Orders
- `POST /api/orders` — JSON: `{"userId":1,"address":"House 10, Lahore","phone":"03001234567"}`
- `GET /api/orders`
- `GET /api/orders/1`

Use Postman to test API routes. For browser requests, the frontend pages already call signup, login, cart and order endpoints.

## Beginner explanation
- A **module** groups one feature, such as ProductsModule.
- A **controller** defines URL routes and receives request data.
- A **service** contains the feature's logic.
- **DataService** reads and writes the JSON file.
- `main.ts` starts NestJS and serves the website files from `public`.

## Lab/demo note
This is a learning project. It uses JSON file storage and SHA-256 password hashing to mirror the supplied lab backend. For real production use, use a database, a password-hashing algorithm such as Argon2/bcrypt, validation DTOs, authentication tokens/sessions and HTTPS.
